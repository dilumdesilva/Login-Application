﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectLibrary
{
    public class Employee
    {

            public int EmpID { get; set; }
            public string EmpName { get; set; }
            public Department objDepartment { get; set; }
            public string Designation { get; set; }
            public string Password { get; set; }
            public int DeptID { get; set; }

    }
}
